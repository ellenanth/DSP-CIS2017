% test settings
scaling_on = true;
add_noise = false;
SNR = 80;       %signal to noise ratio of the added noise
bit_loading_on = false;

%main.m
main;